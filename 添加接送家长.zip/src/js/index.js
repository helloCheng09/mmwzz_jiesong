(function (wall) {
    /**
     * Limit Public
     * Bind wall
     */
    wall.extend({
        // 删除接送名片
        deletcard(itemEle, index) {
            $(itemEle).off().click(function () {
                var $self = $(this)
                let confirmIndex = layer.confirm('是否确定删除次家长？', {
                    title: '妈妈我在这',
                    icon: 3,
                    closeBtn: false,
                }, function () {
                    var index = wall.load({
                        loadstyle: 4,
                        // bg: "transparent",
                    })

                    setTimeout(() => {
                        $self.parents('li').remove()
                        wall.close(index)
                    }, 1000);

                    layer.close(confirmIndex)
                })

            })
        },
        // 相机和相册弹窗选择
        uploadimg(resolve) {
            layui.use('layer', function () {
                var layer = layui.layer;
                var index = layer.open({
                    type: 1,
                    content: `
                        <div class="show-upload-select">
                            <div>
                                <img id="selcamera" src="../img/xiangji.png" class="select-upload-img">
                                <div class="label-tt">
                                    相机拍摄
                                </div>
                            </div>
                            
                            <div>
                                <img id="selalbum" src="../img/xiangce.png" class="select-upload-img">
                                <div class="label-tt">
                                    相册选择
                                </div>
                            </div>
                        </div>
                    `, //这里content是一个普通的String
                    title: false,
                    closeBtn: false,
                    shadeClose: true,
                });
                // 弹出回调
                resolve(index)
            });

        },
        // 移除layui-form-danger样式
        removedanger() {
            $('.layui-input').focus(function () {
                console.log(444)
                $(this).removeClass('layui-form-danger')
            })
        }
    })

    // 入口
    if (document.getElementById('addparentswrap')) {
        // addparentswrap
        listindex()
    }

    /**
     * Functions
     * #1 addparentswrap
     */

    // addparentswrap
    function listindex() {
        // 展示删除按钮
        $('.parent-card-item').off().click(function () {
            var $self = $(this)

            $('.parent-card-item').find('.delet-card').slideUp('fast')
            if ($self.find('.delet-card').css('display') != "block") {
                $self.find('.delet-card').slideToggle('fast')
            }
            // 删除接送名片 
            wall.deletcard('.det-card-btn')

            return false
        })

        // 上传人脸识别图片
        $('#addimgbtn').click(function () {
            wall.uploadimg(function (index) {
                // 选择相机
                $('#selcamera').click(function () {
                    console.log('camera')
                    wx.chooseImage({
                        count: 1, 
                        sizeType: ['compressed'], 
                        sourceType: ['camera'],
                        success: function (res) {
                            var localIds = res.localIds;
                        }
                    });
                    layer.close(index) // 同时关闭弹窗
                })
                // 选择相册
                $('#selalbum').click(function () {
                    console.log('album')
                    wx.chooseImage({
                        count: 1, 
                        sizeType: ['compressed'], 
                        sourceType: ['album'], 
                        success: function (res) {
                            var localIds = res.localIds;
                            
                        }
                    });
                    layer.close(index)
                })
            })
        })

        // 提交接送家长表单
        layui.use('form', function () {
            var form = layui.form;
            wall.removedanger() // 移除danger提示
            form.verify({
                name(val) {
                    if (!val) {
                        return '请填写家长别名'
                    }
                },
                pic(val) {
                    if (!val) {
                        return '请填写家长别名'
                    }
                }
            })
            form.on('submit(subparent)', function (data) {

                console.log(data.field) //被执行事件的元素DOM对象，一般为button对象

                return false
            });


        });


    }


})(window.wall || (window.wall = {}))